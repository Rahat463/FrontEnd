
# include "iGraphics.h"
#include<windows.h>

#define totalbricks 6*15

int getHighScore(void);
void setHighScore(int score);

int i;
int j=0;


char scoreText[90];
char highScoreText[90];
int score=0,Highscore=0;
int x = 475, y = 120, r = 10,ball_x=525,ball_y=150,ex=50,ey=100;
int dx,dy;
int  gameState=-1;
int State=-2;

int getHighScore(void)
{
    FILE *fp = fopen("highscore.txt", "r");

    if (!fp) return 0;

    else
    {
        int highScore;
        fscanf(fp, "%d", &highScore);

        fclose(fp);

        return highScore;
    }
}

void setHighScore(int score)
{
    FILE *fp = fopen("highscore.txt", "w");
    fprintf(fp, "%d", score);
    fclose(fp);
}







/*
	function iDraw() is called again and again by the system.
*/



struct point
{

    int x;
    int y;

} bpoint[3];


char image[10][20]= {"hmenu2.bmp","ins44.bmp","credit41.bmp"};

char homemenu[15]="hmenu2.bmp";
//char play[15]="play11.bmp";
//char score[25]="HIGH_SCORE.bmp";
char ins[25]="ins44.bmp";
char credits[25]="credit41.bmp";

//char quit[25]="quit.bmp";



struct brickstructure
{

    int x;
    int y;
    int dx=100;
    int dy=20;
    bool show=true;

    int red;
    int green;
    int blue;
};

brickstructure bricks[totalbricks];
int red=0;
int green=0;
int blue=0;



void iDraw()
{
    //place your drawing codes here
    iClear();

    if(gameState==-1)
    {
        iShowBMP(0,0,homemenu);
        /* for(int i=0;i<5;i++){
            iShowBMP2(bCordinate[i].x,bCordinate[i].y,button[i],255);

         }*/
    }

    else if(gameState==0)
    {
        iShowBMP(0,0,"LEVEL.bmp");
        iRectangle(ex,ey, 400, 160);


        if(State==0)
        {
            iShowBMP(0,0,"level3.bmp");
            iSetColor(255,255,255);
            iFilledCircle(ball_x, ball_y, r);

            iFilledRectangle(x,y, 100, 20);
            iSetColor(red,green,blue);

            iFilledRectangle(x,y,dx,dy);
            iSetColor(0,255,255);

            sprintf(scoreText, "Your score: %d", score);
            iText(900,780,scoreText,GLUT_BITMAP_TIMES_ROMAN_24);



            for(int i=0; i<totalbricks; i++)
            {
                if(bricks[i].show)
                {


                    iSetColor(bricks[i].red,bricks[i].green,bricks[i].blue);
                    iFilledRectangle(bricks[i].x,bricks[i].y,bricks[i].dx,bricks[i].dy);
                }
            }
        }

        else if(State==1)
        {

            iShowBMP(0,0,"level2.bmp");
            iSetColor(255,255,255);
            iFilledCircle(ball_x, ball_y, r);

            iFilledRectangle(x,y, 100, 20);
            iSetColor(red,green,blue);

            iFilledRectangle(x,y,dx,dy);
            iSetColor(0,255,255);


            sprintf(scoreText, "Your score: %d", score);
            iText(900,780,scoreText,GLUT_BITMAP_TIMES_ROMAN_24);







            for(int i=0; i<totalbricks; i++)
            {
                if(bricks[i].show)
                {


                    iSetColor(bricks[i].red,bricks[i].green,bricks[i].blue);
                    iFilledRectangle(bricks[i].x,bricks[i].y,bricks[i].dx,bricks[i].dy);
                }
            }
            for(i=0; i<totalbricks; i+=2)
            {
                bricks[i].show=false;
            }


        }

        else if(State==2)
        {
            iShowBMP(0,0,"level3.bmp");
            iSetColor(255,255,255);
            iFilledCircle(ball_x, ball_y, r);

            iFilledRectangle(x,y, 100, 20);
            iSetColor(red,green,blue);

            iFilledRectangle(x,y,dx,dy);

            iSetColor(0,255,255);


            sprintf(scoreText, "Your score: %d", score);
            iText(900,780,scoreText,GLUT_BITMAP_TIMES_ROMAN_24);





            for(int i=0; i<totalbricks; i++)
            {
                if(bricks[i].show)
                {


                    iSetColor(bricks[i].red,bricks[i].green,bricks[i].blue);
                    iFilledRectangle(bricks[i].x,bricks[i].y,bricks[i].dx,bricks[i].dy);
                }
            }
            for(i=0; i<totalbricks; i+=3)
            {
                bricks[i].show=false;
            }



        }
        else if(State==3)
        {
            iShowBMP(0,0,"r455.bmp");
            iSetColor(255,255,255);
            iFilledCircle(ball_x, ball_y, r);

            iFilledRectangle(x,y, 100, 20);
            iSetColor(red,green,blue);

            iFilledRectangle(x,y,dx,dy);
            iSetColor(255,0,0);


            sprintf(scoreText, "Your score: %d", score);
            iText(900,780,scoreText,GLUT_BITMAP_TIMES_ROMAN_24);





            for(int i=0; i<totalbricks; i++)
            {
                if(bricks[i].show)
                {


                    iSetColor(bricks[i].red,bricks[i].green,bricks[i].blue);
                    iFilledRectangle(bricks[i].x,bricks[i].y,bricks[i].dx,bricks[i].dy);
                }
            }
            for(i=0; i<totalbricks; i+=4)
            {
                bricks[i].show=false;
            }


        }
    }
    else if(gameState==1)
    {
        iShowBMP(0,0,ins);
    }



    else if(gameState==2)
    {
        iShowBMP(0,0,credits);
    }

    else if(gameState==3)
    {
       iShowBMP(0,0,"GAMEOVER.bmp");
        iSetColor(0,255,255);

        sprintf(scoreText, "Your score: %d", score);
        sprintf(highScoreText, "High score: %d", getHighScore());

        iText(450,300,scoreText,GLUT_BITMAP_TIMES_ROMAN_24
             );
        iText(450,260,highScoreText,GLUT_BITMAP_TIMES_ROMAN_24
             );



    }




    /*  else if(gameState==1)
       {
           iShowBMP(0,0,score);
       }*/




}










void ballChange()
{
    if(State==0||State==1||State==2||State==3)
    {
        ball_x += dx;
        ball_y += dy;

        if(ball_x > 1000)dx=-dx;
        if(ball_y > 800 )dy = -dy;
        if(ball_x <0 )dx=-dx;

        if(ball_y<120){ gameState=3;}

        if(ball_y==150&&x<=ball_x&&((ball_x-x)<100))
        {
            // dx=-dx;
            dy*=(-1);
        }


        //if(ball_y==150&&x<=ball_x&&(ball_x-x>=30)){
        //  dx=-dx;
        //  dy*=(-1);}




        for(int i=0; i<totalbricks; i++)
        {
            if(bricks[i].show)
            {
                if(ball_x>=bricks[i].x&&ball_x<=bricks[i].x+bricks[i].dx)
                {
                    if(ball_y>=bricks[i].y&&ball_y<=bricks[i].y+bricks[i].dy)
                    {

                        dy*=(-1);
                        PlaySound("explosion.wav",NULL,SND_ASYNC);
                        bricks[i].show=false;
                        score++;
                        if (score > getHighScore()) setHighScore(score);

                    }
                }
                else if (ball_y>=bricks[i].y&&ball_y<=bricks[i].y+bricks[i].dy)
                {
                    if(ball_x>=bricks[i].x&&ball_x<=bricks[i].x+bricks[i].dx)
                    {
                        dx*=(-1);
                        PlaySound("explosion.wav",NULL,SND_ASYNC);
                        bricks[i].show=false;
                        score++;
                        if (score > getHighScore()) setHighScore(score);


                    }

                }
            }
        }




        if(ball_x>=x&&ball_x<=x+dx&&ball_y>=y&&ball_y<=y+dy)
        {
            dy*=(-1);

        }




    }



}








/*
	function iMouseMove() is called when the user presses and drags the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouseMove(int x, int y)
{
    //printf("x = %d, y= %d\n",mx,my);
    //place your codes here


}

/*
	function iMouse() is called when the user presses/releases the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouse(int button, int state, int mx, int my)

{
    if(gameState==-1)
    {
        if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
        {
            //place your codes here
            //printf("x = %d, y= %d\n",mx,my);
            for(int i=0; i<3; i++)
            {
                if(mx>=bpoint[i].x&&mx<=bpoint[i].x+260&&my>=bpoint[i].y&&my<=bpoint[i].y+90)
                {
                    gameState=i;
                }

            }
        }
    }

    /*   if(gameState==0){
            if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
    {
       //place your codes here
       //printf("x = %d, y= %d\n",mx,my);
       for(int i=0; i<4; i++)
       {
           if(mx>=bpoint[i].x&&mx<=bpoint[i].x+250&&my>=bpoint[i].y&&my<=bpoint[i].y+100)
           {
               State=i;
           }

       }
       }


    }*/




    else if(button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
    {
        //place your codes here



    }

}
/*
	function iKeyboard() is called whenever the user hits a key in keyboard.
	key- holds the ASCII value of the key pressed.
*/
void iKeyboard(unsigned char key)
{
   /* if(key == 'h')
    {

        gameState=-1;


    }*/
    if(key=='o'&&ey>=100&&ey<=200)
    {
        State=3;
    }
    if(key=='o'&&ey>=260&&ey<=360)
    {
        State=2;
    }
    if(key=='o'&&ey>=380&&ey<=480)
    {
        State=1;
    }
    if(key=='o'&&ey>=500&&ey<=600)
    {
        State=0;
    }
    if(key=='h')
    {
        gameState=-1;
        State=-2;
        ball_y=500;
        ball_x=525;
        score=0;
        x=475;

    }




    //place your codes for other keys here
}

/*
	function iSpecialKeyboard() is called whenver user hits special keys like-
	function keys, home, end, pg up, pg down, arraows etc. you have to use
	appropriate constants to detect them. A list is:
	GLUT_KEY_F1, GLUT_KEY_F2, GLUT_KEY_F3, GLUT_KEY_F4, GLUT_KEY_F5, GLUT_KEY_F6,
	GLUT_KEY_F7, GLUT_KEY_F8, GLUT_KEY_F9, GLUT_KEY_F10, GLUT_KEY_F11, GLUT_KEY_F12,
	GLUT_KEY_LEFT, GLUT_KEY_UP, GLUT_KEY_RIGHT, GLUT_KEY_DOWN, GLUT_KEY_PAGE UP,
	GLUT_KEY_PAGE DOWN, GLUT_KEY_HOME, GLUT_KEY_END, GLUT_KEY_INSERT
*/
void iSpecialKeyboard(unsigned char key)
{

    if(key == GLUT_KEY_RIGHT&&x<900)
    {
        x+=10;
        // ball_x+=10;
    }
    //place your codes for other keys here
    else if(key==GLUT_KEY_LEFT&&x>0)
    {
        x-=10;
        //  ball_x-=10;

    }
    else if(key==GLUT_KEY_UP&&ey<550)
    {
        ey+=160;
    }
    else if(key==GLUT_KEY_DOWN&&ey>100)
    {
        ey-=160;
    }

}

void  definebricks()
{

    int sumx=0;
    int sumy=580;

    for(int i=0; i<totalbricks; i++)
    {

        bricks[i].red=rand()%255;
        bricks[i].green=rand()%255;
        bricks[i].blue=rand()%255;
        bricks[i].x=sumx;
        bricks[i].y=sumy;
        sumx+=100;
        if(sumx>1000)
        {
            sumx=0;
            sumy+=20;
        }
    }


}


int main()
{
    //place your own initialization codes here.
    int sum=50;
    if(gameState==-1)
    {
        for(int i=2; i>=0; i--)
        {
            bpoint[i].x=20;
            bpoint[i].y=sum;
            sum+=250;
        }
    }
    else if(gameState==0)
    {
        for(int i=3; i>=0; i--)
        {
            bpoint[i].x=20;
            bpoint[i].y=sum;
            sum+=250;
        }
    }
    definebricks();


    iSetTimer(10, ballChange);
    dx = 5;
    dy = 5;
    //if(j==2) PlaySound("gameover.wav",NULL,SND_ASYNC);
    if(gameState==-1)PlaySound("Groovy-electronic-background-music.wav",NULL,SND_ASYNC|SND_LOOP);
    iInitialize(1000, 800, " This is a Demo!");
    return 0;
}
